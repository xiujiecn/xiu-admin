import{_ as n,c as s,o as e,ae as p}from"./chunks/framework.Dh1jimFm.js";const h=JSON.parse('{"title":"生成模板","description":"","frontmatter":{"outline":"deep"},"headers":[],"relativePath":"code/template.md","filePath":"code/template.md"}'),t={name:"code/template.md"};function l(i,a,o,c,r,u){return e(),s("div",null,a[0]||(a[0]=[p(`<h1 id="生成模板" tabindex="-1">生成模板 <a class="header-anchor" href="#生成模板" aria-label="Permalink to &quot;生成模板&quot;">​</a></h1><h2 id="业务模板" tabindex="-1">业务模板 <a class="header-anchor" href="#业务模板" aria-label="Permalink to &quot;业务模板&quot;">​</a></h2><p>根据api接口文件一键生成业务模板：api、controller、logic、service</p><h2 id="模板路径配置" tabindex="-1">模板路径配置 <a class="header-anchor" href="#模板路径配置" aria-label="Permalink to &quot;模板路径配置&quot;">​</a></h2><ul><li>模板路径配置：server/hack/config.yaml</li></ul><div class="language- vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang"></span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span># 生成代码</span></span>
<span class="line"><span>xgen:</span></span>
<span class="line"><span>  application:</span></span>
<span class="line"><span>    # CRUD和关系树列表模板</span></span>
<span class="line"><span>    crud:</span></span>
<span class="line"><span>      templates:</span></span>
<span class="line"><span>        # 默认的主包模板</span></span>
<span class="line"><span>        - group: &quot;default&quot;                                              # 分组名称</span></span>
<span class="line"><span>          isAddon: false                                                # 是否为插件模板 false｜true</span></span>
<span class="line"><span>          masterPackage: &quot;gen&quot;                                          # 主包名称，需和controllerPath、logicPath、inputPath保持关联</span></span>
<span class="line"><span>          templatePath: &quot;./resource/generate/default/curd&quot;              # 模板路径</span></span>
<span class="line"><span>          apiPath: &quot;./api/gen&quot;                                          # goApi生成路径</span></span>
<span class="line"><span>          controllerPath: &quot;./internal/controller/gen&quot;                   # 控制器生成路径</span></span>
<span class="line"><span>          logicPath: &quot;./internal/logic/gen&quot;                             # 主要业务生成路径</span></span>
<span class="line"><span>          inputPath: &quot;./internal/model/genin&quot;                           # 表单过滤器生成路径</span></span>
<span class="line"><span>          routerPath: &quot;./internal/router/genrouter&quot;                     # 生成路由表路径</span></span>
<span class="line"><span>          sqlPath: &quot;./manifest/generate&quot;                                # 生成sql语句路径</span></span>
<span class="line"><span>          webApiPath: &quot;../vue/apps/web-antd/src/api/gen&quot;                # webApi生成路径</span></span>
<span class="line"><span>          webViewsPath: &quot;../vue/apps/web-antd/src/views/gen&quot;            # web页面生成路径</span></span></code></pre></div><h2 id="模板目录" tabindex="-1">模板目录 <a class="header-anchor" href="#模板目录" aria-label="Permalink to &quot;模板目录&quot;">​</a></h2><ul><li>模板目录：server/resource/generate/default/curd</li></ul><div class="language- vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang"></span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>server/resource/generate/default/curd</span></span>
<span class="line"><span>├── api.go.template                   # 后端api接口文件</span></span>
<span class="line"><span>├── controller.go.template            # 后端控制器文件</span></span>
<span class="line"><span>├── input.go.template                 # 后端Model定义文件</span></span>
<span class="line"><span>├── logic.go.template                 # 后端业务逻辑文件</span></span>
<span class="line"><span>├── router.go.template                # 后端路由文件</span></span>
<span class="line"><span>├── source.sql.template               # 后端sql语句文件</span></span>
<span class="line"><span>├── web.api.ts.template               # 前端api接口文件</span></span>
<span class="line"><span>├── web.edit.vue.template             # 前端编辑抽屉文件</span></span>
<span class="line"><span>├── web.index.vue.template            # 前端列表页面文件</span></span>
<span class="line"><span>├── web.model.ts.template             # 前端表单模型文件</span></span>
<span class="line"><span>└── web.view.vue.template             # 前端详情抽屉文件</span></span></code></pre></div>`,9)]))}const g=n(t,[["render",l]]);export{h as __pageData,g as default};
